var store = [{
        "title": "David Molina announces candidacy for State Representative District 29",
        "excerpt":"DAVID MOLINA FOR OREGON CAMPAIGN Tuesday, September 19, 2017 FOREST GROVE, Ore. – David Molina, 38, former Army Captain, small business owner and founder of a national veterans nonprofit startup announced his candidacy as Republican for Oregon House of Representatives District 29 today. David has a passion to use his...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/david-molina-announces-candidacy/",
        "teaser":null},{
        "title": "Giving his first stump speech, Candidate Molina shares why he's running before the Beaverton Hillsboro Republican Women Club",
        "excerpt":"PORTLAND, Ore. – This evening, David Molina, Republican candidate for the Oregon House of Representatives, District 29, gave his first stump speech about his run for public office before an audience of strong conservative women, elected officials, candidates for public office, Republican PCPs, and business owners. \"When I couldn't use...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/beaverton-hillsboro-republican-women-club/",
        "teaser":null},{
        "title": "State Representative Bill Post interviews David Molina who's running to represent Forest Grove, Cornelius and West Hillsboro as State Representative",
        "excerpt":"DAVID MOLINA FOR OREGON CAMPAIGN Tuesday, September 26, 2017 KEIZER, Ore. – Today, Bill Post, an American politician, military brat and conservative talk radio personality interviewed former Army Captain David Molina who’s running for Oregon House District 29, which includes Forest Grove, Cornelius, downtown Hillsboro through Brookwood. The district is...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/bill-post-interviews-david-molina-running-for-state-representative-house-district-29/",
        "teaser":null},{
        "title": "Forest Grove Republican running for House District 29",
        "excerpt":"JILL REHKOPF SMITH via Pamplin Media, Forest Grove News Times Thursday, September 28, 2017 FOREST GROVE, Ore. – Eight months before the May primary election, Forest Grove resident David Molina, a Republican, has announced his candidacy for Oregon House District 29, now held by state Rep. Susan McLain, a Democrat....","categories": [],
        "tags": [],
        "url": "https://__baseurl__/forest-grove-republican-for-house-district-29/",
        "teaser":null},{
        "title": "Republican PCP, David Molina, represents at the Oregon GOP Platform Convention",
        "excerpt":"[L-R: Alexander Flores, David Molina, and Tracy Honl] BEND, Ore. – Over the weekend, hundreds of conservative Oregonians representing every county in the state converged onto central Oregon to conduct the state’s business, including the Republican platform, network and connect, and share ideas for good governance. State Party Chair, Bill...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/oregon-gop-platform-convention/",
        "teaser":null},{
        "title": "David Molina speaks at the Hillsboro Chamber Conectate Latino Small Business Coffee Hour",
        "excerpt":"HILLSBORO, Ore. – This morning on a freezing Washington County morning, over two dozen Latino small business owners and entrepreneurs huddled together to network, connect, and learn strategies to grow their businesses. Hillsboro Chamber Latino Program Specialist, Claudia Cardenas, welcomed everyone and shared the groups’ 2017 progress and asked for...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/hillsboro-chamber-conectate/",
        "teaser":null},{
        "title": "Campaign Kickoff Fundraiser for David Molina House District 29",
        "excerpt":"DAVID MOLINA FOR OREGON CAMPAIGN Monday, March 12, 2018 CORNELIUS, Ore. – Friends, family and voters are invited to meet David Molina, candidate for House District 29 (Forest Grove, Cornelius and West Hillsboro) at the Campaign Kickoff scheduled for Wednesday, March 28, 2018 starting at 6:00 pm at former Cornelius...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/campaign-kickoff/",
        "teaser":null},{
        "title": "The expensive and inexpensive reasons for Portland-metro travel",
        "excerpt":"Randal O’Toole is a Cato Institute Senior Fellow working on urban growth, public land, and transportation issues. He spoke before a large crowd at the SW Corridor meeting. Remember: an informed citizen makes the best decisions. If you can’t watch it above, click here to be redirected to YouTube. CATO...","categories": [],
        "tags": [],
        "url": "https://__baseurl__/sw-corridor-randall-otoole/",
        "teaser":null}]
